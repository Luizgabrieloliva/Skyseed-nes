SKYSEED — NATIVE WINDOWS BUILD
================================

Files
-----
Skyseed.exe       Standalone Windows x64 GUI executable.
Skyseed_Port.cpp  C++ source for the native port.

How to run
----------
1. Extract Skyseed.exe from the ZIP (or use the standalone EXE directly).
2. Double-click Skyseed.exe on Windows 10/11 x64.
3. The game starts immediately; no .nes ROM, emulator, browser, or extra asset
   file is required.

Controls
--------
Arrow keys or WASD: move
R / Space / Enter: restart after Game Over
Esc: exit

Reconstruction notes
--------------------
The supplied file is a valid iNES/NROM (mapper 0) ROM with 32 KiB of PRG
program/data and 8 KiB of CHR graphics. The native build reproduces the
identified game logic directly: player movement, the moving collectible,
the moving hazard, collision checks, score (up to 99), three lives, and the
Game Over screen. The ROM's sprite pattern table is embedded in the EXE.

This is a native reimplementation, not a 6502 CPU emulator and not a wrapper
around an emulator. The EXE does not load or need the original .nes file.
The original filename supplied the displayed project name; no readable title
string was found in the ROM's program data. The NES palette is represented
using a conventional NTSC RGB approximation. The original program contains
no evident sound playback routine, so this port is silent.

Build / verification
--------------------
Target: Windows x64 (PE32+ GUI)
Implementation: native C++ and Win32/GDI; no external runtime dependency.
Static verification: PE32+ x86-64 executable format confirmed; no import-table
DLL dependencies; original ROM is not required at runtime.

Important limitation: this build was cross-compiled and inspected in a Linux
build environment. It could not be launched here because a Windows runtime
or Wine is not available. Please test it on Windows; if Windows displays a
compatibility or startup error, share the exact message for a correction.
